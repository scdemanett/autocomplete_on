autocomplete_on
===============

Changes 'autocomplete=off' to 'autocomplete=on' in web pages, so your passwords will be remembered.

Clone of https://chrome.google.com/webstore/detail/autocomplete-on/ecpgkdflcnofdbbkiggklcfmgbnbabhh/related
made a clone because i couldn't trust that the other one wouldn't be auto-updated and start stealing my passwords.

I don't trust any extensions that want access to all websites I visit!

Consider making your own clone :)

source code: https://github.com/kzahel/autocomplete_on
